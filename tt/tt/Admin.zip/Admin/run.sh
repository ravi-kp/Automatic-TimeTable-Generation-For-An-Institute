gcc color_generator.c -o color_generator &&
./color_generator &&
gcc tt_1.c -o input_graph &&
./input_graph &&
gcc tt_2.c -o final_output &&
./final_output &&
gcc new_format.c -o new_format &&
./new_format
