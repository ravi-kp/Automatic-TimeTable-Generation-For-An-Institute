<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>   
              <!--  <li><a href="faculty_details.php">Faculty<span class="tab-l"></span><span class="tab-r"></span></a></li>   -->
				<li><a href="sampaddc.php">Add Course<span class="tab-l"></span><span class="tab-r"></span></a></li>
	     		<li><a href="add_room.php">Add Room<span class="tab-l"></span><span class="tab-r"></span></a></li> 
                <li><a href="add_slots.php">Add Slots<span class="tab-l"></span><span class="tab-r"></span></a></li>  
                <li><a href="select_course.php">Select Courses<span class="tab-l"></span><span class="tab-r"></span></a></li> 				
                <li><a href="generated.php"><font color="red">Generate Time Table</font><span class="tab-l"></span><span class="tab-r"></span></a></li>				
              <!--  <li><a href="Logout.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>     --->    
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->
